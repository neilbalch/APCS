Neil Balch's Sim City Lab

Challenge #s: 1 and 2