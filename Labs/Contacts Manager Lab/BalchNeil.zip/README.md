# Contacts Manager Lab

By: Neil Balch, P1

**Challenge:** 2, Add buttons for sorting the list A->Z by first name, last name or email.