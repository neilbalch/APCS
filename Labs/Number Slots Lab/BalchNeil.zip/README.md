# Balch, Neil: Number Slots Lab

Challenge: _Sounds, hence the three .wav files in the zip. Make sure they get to the same directory as the classes_