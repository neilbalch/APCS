# Neil Balch's Blackjack Lab

## Challenge completed: Ace is either worth 11 or 1 depending on hand value.