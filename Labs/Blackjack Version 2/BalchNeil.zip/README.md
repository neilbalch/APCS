# BlackJack Version 2 Lab

##Challenge Completed: Ace is worth 1 or 11 to advantage of player and dealer.