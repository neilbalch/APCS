Challenge #3: There's more than one projectile available.

Neil Balch