# Neil's Pixel Art Lab

Chellange Completed: export image to `png`.